@echo off
cd /d "%~dp0"

rem 90 == RESTART_REQUESTED_EXIT_CODE: the program asks to be restarted (hung board/mail-poll watchdog).
rem Any other exit code (0 == normal quit, anything else == error) ends the loop.

:run_loop
"%~dp0MM-FIDO.exe"
set "STATUS=%errorlevel%"
if "%STATUS%"=="90" (
    echo.
    echo Restarting...
    goto run_loop
)
if not "%STATUS%"=="0" (
    echo.
    echo The program exited with an error ^(see above and mm-fido.log^).
    pause
)
exit /b %STATUS%
