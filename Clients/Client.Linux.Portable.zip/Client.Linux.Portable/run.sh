#!/usr/bin/env bash
cd "$(dirname "$0")"
chmod +x MM-FIDO 2>/dev/null

# 90 == RESTART_REQUESTED_EXIT_CODE: the program asks to be restarted (hung board/mail-poll watchdog).
# Any other exit code (0 == normal quit, anything else == error) ends the loop.
RESTART_REQUESTED_EXIT_CODE=90

while true; do
    ./MM-FIDO
    status=$?
    if [ $status -eq $RESTART_REQUESTED_EXIT_CODE ]; then
        echo
        echo "Restarting..."
        continue
    fi
    exit $status
done
